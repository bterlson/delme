const {
  BlobServiceClient,
  StorageSharedKeyCredential
} = require("@azure/storage-blob");


async function main() {
  const account = process.env.ACCOUNT_NAME || "bterlsondelme";
  const accountKey =
    process.env.ACCOUNT_KEY ||
    "oi6kjs80HMttZeup0bbjWWgM7Az4PPVtHwfUKciEanNriCWNXoGwVzNXHQzXbiD79zmwCm8f7fozaxJjZN7k+A==";

  const sharedKeyCredential = new StorageSharedKeyCredential(
    account,
    accountKey
  );

  const blobServiceClient = new BlobServiceClient(
    `https://${account}.blob.core.windows.net`,
    sharedKeyCredential,
    {
      /*
      proxyOptions : {
        // To use these options, remove the section above that checks for HTTP_PROXY or HTTPS_PROXY
        host: "http://localhost",
        port: 3128,
        username: "<username>",
        password: "<password>"
      }
      */
    }
  );

  // Create a container
  const containerName = `newcontainer${new Date().getTime()}`;
  const createContainerResponse = await blobServiceClient
    .getContainerClient(containerName)
    .create();
  console.log(
    `Created container ${containerName} successfully`,
    createContainerResponse.requestId
  );
}

main().catch(err => {
  console.error("Error running sample:", err.message);
});
