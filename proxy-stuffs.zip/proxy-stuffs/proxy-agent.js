var http = require("http");
var ProxyAgent = require("proxy-agent");

var proxyUri = process.env.http_proxy;

var opts = {
  method: "GET",
  host: "jsonip.org",
  path: "/",
  agent: new ProxyAgent(proxyUri)
};

http.get(opts, onresponse);

function onresponse(res) {
  console.log(res.statusCode, res.headers);
  res.pipe(process.stdout);
}
